Readme file for source code:

Download the covidfight zip file.
Upload all the modules in visual studios.
Install pygame by using the command >> pip install pygame
Run the main.py module.
To execute the file, use the command >>python3 main.py in the terminal.
